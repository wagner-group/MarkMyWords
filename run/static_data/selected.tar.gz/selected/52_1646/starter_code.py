def green(n):
	