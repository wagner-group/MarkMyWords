class Solution:
    def solveNQueens(self, n: int) -> List[List[str]]:
        