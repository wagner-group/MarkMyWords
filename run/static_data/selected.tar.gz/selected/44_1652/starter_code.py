def format_duration(seconds):
	