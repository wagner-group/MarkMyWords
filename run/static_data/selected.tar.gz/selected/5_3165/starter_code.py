def toothpick(n):
	