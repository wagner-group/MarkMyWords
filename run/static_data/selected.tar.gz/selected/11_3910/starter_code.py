def operator_insertor(n):
	