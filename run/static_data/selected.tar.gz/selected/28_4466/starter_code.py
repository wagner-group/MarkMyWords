def print_number(number, char):
	