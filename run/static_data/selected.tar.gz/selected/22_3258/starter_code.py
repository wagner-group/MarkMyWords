def transpose(amount, tab):
	