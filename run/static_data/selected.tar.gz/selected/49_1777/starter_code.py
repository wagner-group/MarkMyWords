def edge_detection(image):
	