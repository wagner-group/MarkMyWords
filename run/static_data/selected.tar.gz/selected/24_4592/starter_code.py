def play_OX_3D(moves):
	