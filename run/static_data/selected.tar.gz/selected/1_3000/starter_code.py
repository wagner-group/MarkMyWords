def mul_power(n, k):
	