def __init__(self, op=None, left=None, right=None):
	