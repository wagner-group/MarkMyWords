def ROTF(U,L,F,R,B,D):
	