def solve(*equations):
	