def productsum(n):
	