class Solution:
    def numSquares(self, n: int) -> int:
        