def exp_sum(n):
	