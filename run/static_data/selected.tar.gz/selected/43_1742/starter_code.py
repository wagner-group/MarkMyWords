def combos(n):
	