def rpg(field, actions):
	