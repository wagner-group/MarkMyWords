def solve(a, b):
	