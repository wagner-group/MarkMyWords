def amazon_check_mate(king, amazon):
	