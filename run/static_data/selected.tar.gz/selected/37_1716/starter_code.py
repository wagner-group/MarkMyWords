def equal_to_24(a,b,c,d):
	