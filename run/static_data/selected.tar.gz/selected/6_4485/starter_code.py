def HQ9(code):
	