def gap(g, m, n):
	