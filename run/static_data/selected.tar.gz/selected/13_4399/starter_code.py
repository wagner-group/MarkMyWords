def fold_cube(nums):
	