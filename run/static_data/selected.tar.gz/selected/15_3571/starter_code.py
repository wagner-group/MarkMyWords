def is_divisible(wall_length, pixel_size):
	