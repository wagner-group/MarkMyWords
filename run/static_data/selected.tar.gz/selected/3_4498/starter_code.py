def solution(roman):
	