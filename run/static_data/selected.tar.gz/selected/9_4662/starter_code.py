def solve(n):
	